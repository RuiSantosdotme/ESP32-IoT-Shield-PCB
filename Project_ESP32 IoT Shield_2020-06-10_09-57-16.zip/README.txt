The IoT sensor shield is designed to be stacked to the ESP32. For this reason, if you want to use our PCB, you need the same ESP32 board. We’re using the ESP32 DEVKIT DOIT V1 board (the model with 36 GPIOs). The shield is equipped with a BME280 sensor, an LDR, a PIR motion sensor, a status LED, a pushbutton and a socket to connect a relay module or any other output.
[https://randomnerdtutorials.com/](Complete project details): [https://randomnerdtutorials.com/](https://randomnerdtutorials.com/)            
How to use：

At editor, Click the document icon on the topbar, via "Document" > "Open" > "EasyEDA Source", and select json file, then open it at the editor.



如何使用：

在编辑器顶部工具栏，点击“文档”图标，选择 “文档” > “打开” > “EasyEDA源码”，选择json文件打开即可。